const path = {
    HOME: '/',
    LIST: '/list'
}

export default path;